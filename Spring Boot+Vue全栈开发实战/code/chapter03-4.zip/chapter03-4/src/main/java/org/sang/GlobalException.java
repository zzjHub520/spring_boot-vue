package org.sang;

import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * Created by sang on 2018/7/10.
 */
@ControllerAdvice
public class GlobalException {
}
