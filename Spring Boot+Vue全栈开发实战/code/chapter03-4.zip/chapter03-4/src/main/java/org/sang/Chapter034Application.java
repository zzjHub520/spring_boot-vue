package org.sang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter034Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter034Application.class, args);
	}
}
