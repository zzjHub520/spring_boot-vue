package org.sang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter032Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter032Application.class, args);
	}
}
