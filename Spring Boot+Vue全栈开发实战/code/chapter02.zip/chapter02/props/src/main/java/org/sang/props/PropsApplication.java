package org.sang.props;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PropsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PropsApplication.class, args);
    }
}
