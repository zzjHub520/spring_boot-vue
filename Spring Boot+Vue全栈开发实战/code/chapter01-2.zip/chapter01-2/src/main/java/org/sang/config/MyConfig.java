package org.sang.config;

import org.springframework.context.annotation.Configuration;

/**
 * Created by sang on 2018/7/4.
 */
@Configuration
public class MyConfig {
}
