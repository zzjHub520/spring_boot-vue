package org.sang.validation;

public interface ValidationGroup1 {
}
