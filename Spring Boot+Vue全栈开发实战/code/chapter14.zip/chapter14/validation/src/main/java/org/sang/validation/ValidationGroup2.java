package org.sang.validation;

public interface ValidationGroup2 {
}
