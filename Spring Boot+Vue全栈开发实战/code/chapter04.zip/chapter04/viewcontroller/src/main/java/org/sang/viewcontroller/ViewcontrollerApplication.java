package org.sang.viewcontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViewcontrollerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ViewcontrollerApplication.class, args);
    }
}
