package org.sang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImportxmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImportxmlApplication.class, args);
	}
}
