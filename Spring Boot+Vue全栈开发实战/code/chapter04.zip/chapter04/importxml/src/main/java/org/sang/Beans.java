package org.sang;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Created by sang on 2018/7/13.
 */
@Configuration
@ImportResource("classpath:beans.xml")
public class Beans {
}
