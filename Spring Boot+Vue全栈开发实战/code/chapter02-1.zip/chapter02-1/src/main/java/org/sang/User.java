package org.sang;

import java.util.List;

/**
 * Created by sang on 2018/7/5.
 */
public class User {
    private String name;
    private String address;
    private List<String> favorites;
}
