package org.sang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter021Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter021Application.class, args);
	}
}
