package org.sang.mapper1;

import org.sang.model.Book;

import java.util.List;

/**
 * Created by sang on 2018/7/16.
 */
public interface BookMapper {
    List<Book> getAllBooks();
}
