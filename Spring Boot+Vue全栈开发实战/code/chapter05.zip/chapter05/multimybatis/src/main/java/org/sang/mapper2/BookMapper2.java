package org.sang.mapper2;

import org.sang.model.Book;

import java.util.List;

/**
 * Created by sang on 2018/7/16.
 */
public interface BookMapper2 {
    List<Book> getAllBooks();
}
