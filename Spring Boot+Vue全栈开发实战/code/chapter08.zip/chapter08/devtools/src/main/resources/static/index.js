function aaa() {
    return "aaa ccc ddd";
}