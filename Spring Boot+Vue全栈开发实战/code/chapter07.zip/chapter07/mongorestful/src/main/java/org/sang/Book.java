package org.sang;

/**
 * Created by sang on 2018/7/21.
 */
public class Book {
    private Integer id;
    private String name;
    private String author;
    //省略getter/setter
}
