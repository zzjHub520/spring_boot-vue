package org.sang.rabbitmq;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitProducerConfig {
}
